package com.test;

import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.rpc.ServiceException;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;

public class Test {
	
	 public static void main(String[] args) {
		String url="http://192.168.8.101:8080/YBT_webservices/services/SFPService";
		String a="陈彪";
		Service service = new Service();
		Call call;
		Object[] object = new Object[2];
		object[0]="001";
		object[1]="陈彪";
		try {
			call = (Call) service.createCall();
			call.setTargetEndpointAddress(url);// 远程调用路径
//			call.setOperationName(method);// 调用的方法名
			call.setOperationName(new QName("http://SFPSend.util.com/", "getRecevice"));
			try {
				call.setTimeout(15000);//15秒超时
			} catch (Exception e) {
				System.out.println("连接超时");
				e.printStackTrace();
			}
		
			String result = (String) call.invoke(object);// 远程调用
			System.out.println(result);
		} catch (ServiceException e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}
 
 
 
 
 
 
 
 

	
}
