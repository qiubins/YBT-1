package com.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;


import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;


public class SFPSend {	  			 	   
	   	
		public  String send(String url,String xml,String encoding) {  
			
	        String body="";
			try {
				body = "";  
				//创建httpclient对象  
				CloseableHttpClient client = HttpClients.createDefault();  
				//创建post方式请求对象  
				HttpPost httpPost = new HttpPost(url);  
				//设置请求参数
				System.out.println(xml);
				StringEntity paramEntity = new StringEntity(xml);
				httpPost.setEntity(paramEntity);
				System.out.println("请求地址："+url);  
				System.out.println("请求参数："+paramEntity);  
				//设置header信息  
				//指定报文头【Content-type】、【User-Agent】  
				httpPost.setHeader("Content-type", "text/xml; charset=GBK");  
				httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");  
				//执行请求操作，并拿到结果（同步阻塞）  
				CloseableHttpResponse response = client.execute(httpPost);  
				//获取结果实体  
				HttpEntity entity = response.getEntity(); 
				if (entity != null) {  
				    //按指定编码转换结果实体为String类型  
				    body = EntityUtils.toString(entity, encoding);  
				}  
				EntityUtils.consume(entity);  
				//释放链接  
				response.close();
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (org.apache.http.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
	        return body;  
	    } 
		
	
}
