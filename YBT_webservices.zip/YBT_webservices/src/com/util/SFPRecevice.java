package com.util;

import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

public class SFPRecevice {	  			 	   
	   	
		public String getRecevice(String code ,String xml){
			System.out.println("进入前置机");
			System.out.println("收到===="+xml);
			WebServiceConfig w=new WebServiceConfig();
			
			Document cConfDoc=w.load();
			@SuppressWarnings("unchecked")
			List<Element> mSocketList = cConfDoc.getRootElement().getChildren("bea");
			String result=null;
			for (int i = 0; i < mSocketList.size(); i++) {
				Element ttSocket = mSocketList.get(i);
				if(ttSocket.getChildText("id").equals(code)){
					System.out.println(ttSocket.getChildText("name"));
					SFPSend s=new SFPSend();
					result=s.send(ttSocket.getChildText("URL"), xml, "UTF-8");
					break;
				}else{
					continue;
				}
				
			}
			return result;
			
		}
		
	
}
