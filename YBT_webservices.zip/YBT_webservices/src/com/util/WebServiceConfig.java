package com.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.rmi.RemoteException;

import javax.xml.namespace.QName;

import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.encoding.XMLType;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.jdom.Document;

import com.sinosoft.midplat.common.JdomUtil;




public class WebServiceConfig {

	
	
	
	public Document load() {
		
		String cPath=WebServiceConfig.class.getResource("").getPath().substring(0, WebServiceConfig.class.getResource("").getPath().indexOf("WEB-INF"))+"conf/bea.xml";
		String mFilePath =  cPath;
		
		File cConfFile = new File(mFilePath);
		/**
		 * 一定要在加载之前记录文件属性。
		 * 文件的加载到文件属性设置之间存在细微的时间差，
		 * 如果恰巧在此时间差内外部修改了文件，
		 * 那么记录的数据就是新修改后的，导致这次修改不会自动被加载；
		 * 将文件属性设置放在加载之前，就算在时间差内文件发生改变，
		 * 由于记录的是旧的属性，系统会在下一个时间单元重新加载，
		 * 这样顶多会导致同一文件多加载一次，但不会出现修改而不被加载的bug。
		 */
	
		
		Document cConfDoc = loadXml(cConfFile);
		JdomUtil.print(cConfDoc);
		return cConfDoc;
	}
	
	protected Document loadXml(File pFile) {
		InputStream mXmlIs = null;
		try {
			mXmlIs = new FileInputStream(pFile);
		} catch (FileNotFoundException ex) {
			ex.getCause().getMessage();
		}
		return JdomUtil.build(mXmlIs, "utf-8");
	}
	
	
	
	
	
	
	

}
